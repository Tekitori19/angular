import { Component } from '@angular/core';

@Component({
  selector: 'app-lab7',
  standalone: false,
  templateUrl: './lab7.component.html',
  styleUrl: './lab7.component.css'
})
export class Lab7Component {

}
