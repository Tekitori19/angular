export const environment = {
    production: false,
    apiToken: '5f4cda310e7ffaf62a632f469cf5fa168aa215d79ce372069dd12c8f5c34fe09'
};
