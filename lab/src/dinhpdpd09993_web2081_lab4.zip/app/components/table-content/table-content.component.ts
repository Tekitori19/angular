import { Component } from '@angular/core';

@Component({
  selector: 'app-table-content',
  standalone: false,
  templateUrl: './table-content.component.html',
  styleUrl: './table-content.component.css'
})
export class TableContentComponent {

}
